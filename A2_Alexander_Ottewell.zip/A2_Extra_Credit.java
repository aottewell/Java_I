/*CS 111 - Programming Style Sheet
 Chapter No. 1 - Exercise No. Extra_Credit
 File Name: A2_Extra Credit.java
 Programmer: Alexander Ottewell
 Date Last Modified: Sept. 6, 2016
 Problem Statement:  Ask the user to open attached file, read in two integers and the string, then print all three to the screen.
                     Close the file at the end.

Overall Plan:
1) Print an initial welcoming message to the screen
2) Open attached file
3) Read the file and print content to the screen
4) Close the file

Classes needed and Purpose: �Scanner� will be needed for general purpose
 input and output from the terminal


*/import java.io.BufferedReader; //Scanner
  import java.io.FileReader;
  
  public class Extra_Credit
  {
  	public static void main (String [] args) throws Exception
  	{
  		
  		FileReader file = new FileReader ("C:/Users/Alex/Desktop/A2.txt");
  		BufferedReader reader = new BufferedReader (file);
  		
  		String text = "";
  		String line = reader.readLine();
  		
  		{ 
  		
  		text += line;
  		line = reader.readLine ();
  		
  		}
  		
  		System.out.println(text);
  	}
  }
  